U1 Diagnostic Evidence Bundle (U1-DEB) v1
Produced by U1 Doctor (unofficial, not affiliated with Snapmaker). Read-only forensics: it never commands the printer.
Replay: re-run the deterministic rules in findings.json's ruleset over observations.jsonl; results must match byte for byte.
Source mix: SYNTHETIC. SYNTHETIC means fabricated demo data, not a real machine.
Integrity: SHA-256 proves these files are unchanged. It does NOT prove who made them or that they came from a real U1.
Privacy: redaction is best-effort; review the content and obtain consent before sharing.
Spec: docs/U1-DEB.md in the U1 Doctor repository.
